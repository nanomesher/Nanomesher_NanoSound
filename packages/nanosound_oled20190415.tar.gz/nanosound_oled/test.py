#!/usr/bin/env python


from __future__ import unicode_literals
from luma.core.interface.serial import i2c, spi 
from luma.core.render import canvas
from luma.oled.device import ssd1306, ssd1325, ssd1331, sh1106
from luma.core import cmdline, error

import sys

def get_device(actual_args=None):
    """
    Create device from command-line arguments and return it.
    """
    #if actual_args is None:
    #    actual_args = sys.argv[1:]

    actual_args = ['-f','conf/ssd1351.conf']
    parser = cmdline.create_parser(description='luma.examples arguments')
    args = parser.parse_args(actual_args)
    print(args.config)

    if args.config:
        # load config from file
        config = cmdline.load_config(args.config)
        args = parser.parse_args(config + actual_args)

    #print(display_settings(args))

    # create device
    try:
        device = cmdline.create_device(args)
    except error.Error as e:
        parser.error(e)

    return device


device = get_device()
