"""
Empty initializer
"""
